# Feed and Speed Calculator
# Provides a basic feeds and speeds calculator for use with FreeCAD Path

import os

from PySide import QtGui

import FreeCAD
import FreeCADGui

dir = os.path.dirname(__file__)
ui_name = "CAMMachDoorCAMConfigGui.ui"
path_to_ui = os.path.join(dir, ui_name)
iconPath = os.path.join(dir, 'Icons')
ParamOffset1 = "MachDoorCAMConfigOffset1"
ParamOffset2 = "MachDoorCAMConfigOffset2"
ParamOffset3 = "MachDoorCAMConfigOffset3"
ParamOffset4 = "MachDoorCAMConfigOffset4"
ParamT1 = "MachDoorCAMConfigT1Length"
ParamT2 = "MachDoorCAMConfigT2Length"
ParamT3 = "MachDoorCAMConfigT3Length"
ParamT4 = "MachDoorCAMConfigT4Length"
ParamT5 = "MachDoorCAMConfigT5Length"
ParamT6 = "MachDoorCAMConfigT6Length"
ParamT7 = "MachDoorCAMConfigT7Length"
ParamT8 = "MachDoorCAMConfigT8Length"
ParamT9 = "MachDoorCAMConfigT9Length"
ParamT10 = "MachDoorCAMConfigT10Length"
ParamT11 = "MachDoorCAMConfigT11Length"
ParamT12 = "MachDoorCAMConfigT12Length"
ParamT13 = "MachDoorCAMConfigT13Length"
ParamT14 = "MachDoorCAMConfigT14Length"
ParamT15 = "MachDoorCAMConfigT15Length"
ParamT16 = "MachDoorCAMConfigT16Length"
ParamT17 = "MachDoorCAMConfigT17Length"
ParamT18 = "MachDoorCAMConfigT18Length"
ParamT19 = "MachDoorCAMConfigT19Length"
ParamT20 = "MachDoorCAMConfigT20Length"

def preferences():
    return FreeCAD.ParamGet("User parameter:BaseApp/Preferences/Mod/CAM")

def getParamOffset1():
    pref = preferences()
    return pref.GetFloat(ParamOffset1, 0.01)

def getParamOffset2():
    pref = preferences()
    return pref.GetFloat(ParamOffset2, 0.01)

def getParamOffset3():
    pref = preferences()
    return pref.GetFloat(ParamOffset3, 0.01)

def getParamOffset4():
    pref = preferences()
    return pref.GetFloat(ParamOffset4, 0.01)

def getParamT1():
    pref = preferences()
    return pref.GetFloat(ParamT1, 0.000)

def getParamT2():
    pref = preferences()
    return pref.GetFloat(ParamT2, 0.000)

def getParamT3():
    pref = preferences()
    return pref.GetFloat(ParamT3, 0.000)

def getParamT4():
    pref = preferences()
    return pref.GetFloat(ParamT4, 0.000)

def getParamT5():
    pref = preferences()
    return pref.GetFloat(ParamT5, 0.000)

def getParamT6():
    pref = preferences()
    return pref.GetFloat(ParamT6, 0.000)

def getParamT7():
    pref = preferences()
    return pref.GetFloat(ParamT7, 0.000)

def getParamT8():
    pref = preferences()
    return pref.GetFloat(ParamT8, 0.000)

def getParamT9():
    pref = preferences()
    return pref.GetFloat(ParamT9, 0.000)

def getParamT10():
    pref = preferences()
    return pref.GetFloat(ParamT10, 0.000)

def getParamT11():
    pref = preferences()
    return pref.GetFloat(ParamT11, 0.000)

def getParamT12():
    pref = preferences()
    return pref.GetFloat(ParamT12, 0.000)

def getParamT13():
    pref = preferences()
    return pref.GetFloat(ParamT13, 0.000)

def getParamT14():
    pref = preferences()
    return pref.GetFloat(ParamT14, 0.000)

def getParamT15():
    pref = preferences()
    return pref.GetFloat(ParamT15, 0.000)

def getParamT16():
    pref = preferences()
    return pref.GetFloat(ParamT16, 0.000)

def getParamT17():
    pref = preferences()
    return pref.GetFloat(ParamT17, 0.000)

def getParamT18():
    pref = preferences()
    return pref.GetFloat(ParamT18, 0.000)

def getParamT19():
    pref = preferences()
    return pref.GetFloat(ParamT19, 0.000)

def getParamT20():
    pref = preferences()
    return pref.GetFloat(ParamT20, 0.000)

def setParamOffset1(offset1=1.111):
    pref = preferences()
    return pref.SetFloat(ParamOffset1, offset1)

def setParamOffset2(offset2=2.222):
    pref = preferences()
    return pref.SetFloat(ParamOffset2, offset2)

def setParamOffset3(offset3=3.333):
    pref = preferences()
    return pref.SetFloat(ParamOffset3, offset3)

def setParamOffset4(offset4=4.444):
    pref = preferences()
    return pref.SetFloat(ParamOffset4, offset4)

def setParamT1(t1Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT1, t1Length)

def setParamT2(t2Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT2, t2Length)

def setParamT3(t3Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT3, t3Length)

def setParamT4(t4Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT4, t4Length)

def setParamT5(t5Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT5, t5Length)

def setParamT6(t6Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT6, t6Length)

def setParamT7(t7Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT7, t7Length)

def setParamT8(t8Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT8, t8Length)

def setParamT9(t9Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT9, t9Length)

def setParamT10(t10Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT10, t10Length)

def setParamT11(t11Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT11, t11Length)

def setParamT12(t12Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT12, t12Length)

def setParamT13(t13Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT13, t13Length)

def setParamT14(t14Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT14, t14Length)

def setParamT15(t15Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT15, t15Length)

def setParamT16(t16Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT16, t16Length)

def setParamT17(t17Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT17, t17Length)

def setParamT18(t18Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT18, t18Length)

def setParamT19(t19Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT19, t19Length)

def setParamT20(t20Length=0.000):
    pref = preferences()
    return pref.SetFloat(ParamT20, t20Length)

class MachDoorCAMConfigPanel():
    def __init__(self):
        # Build GUI
        self.form = FreeCADGui.PySideUic.loadUi(path_to_ui)

        # Init
        #self.calculation = CAMMachDoorCAMConfig.FSCalculation()
        self.setup_ui()
        #self.calculate()
        self.form.update_PB.clicked.connect(self.saveParameters)
        self.form.close_PB.clicked.connect(self.quit)

        #self.form.doubleSpinBox_offset1.setText("5.000")

    def setup_ui(self):
        self.populateFormFields()

    def populateFormFields(self):
        self.form.doubleSpinBox_offset1.setValue(float(getParamOffset1()))
        self.form.doubleSpinBox_offset2.setValue(float(getParamOffset2()))
        self.form.doubleSpinBox_offset3.setValue(float(getParamOffset3()))
        self.form.doubleSpinBox_offset4.setValue(float(getParamOffset4()))
        self.form.doubleSpinBox_T1.setValue(float(getParamT1()))
        self.form.doubleSpinBox_T2.setValue(float(getParamT2()))
        self.form.doubleSpinBox_T3.setValue(float(getParamT3()))
        self.form.doubleSpinBox_T4.setValue(float(getParamT4()))
        self.form.doubleSpinBox_T5.setValue(float(getParamT5()))
        self.form.doubleSpinBox_T6.setValue(float(getParamT6()))
        self.form.doubleSpinBox_T7.setValue(float(getParamT7()))
        self.form.doubleSpinBox_T8.setValue(float(getParamT8()))
        self.form.doubleSpinBox_T9.setValue(float(getParamT9()))
        self.form.doubleSpinBox_T10.setValue(float(getParamT10()))
        self.form.doubleSpinBox_T11.setValue(float(getParamT11()))
        self.form.doubleSpinBox_T12.setValue(float(getParamT12()))
        self.form.doubleSpinBox_T13.setValue(float(getParamT13()))
        self.form.doubleSpinBox_T14.setValue(float(getParamT14()))
        self.form.doubleSpinBox_T15.setValue(float(getParamT15()))
        self.form.doubleSpinBox_T16.setValue(float(getParamT16()))
        self.form.doubleSpinBox_T17.setValue(float(getParamT17()))
        self.form.doubleSpinBox_T18.setValue(float(getParamT18()))
        self.form.doubleSpinBox_T19.setValue(float(getParamT19()))
        self.form.doubleSpinBox_T20.setValue(float(getParamT20()))

    def saveParameters(self):
        offset1 = self.form.doubleSpinBox_offset1.value()
        setParamOffset1(offset1)
        offset2 = self.form.doubleSpinBox_offset2.value()
        setParamOffset2(offset2)
        offset3 = self.form.doubleSpinBox_offset3.value()
        setParamOffset3(offset3)
        offset4 = self.form.doubleSpinBox_offset4.value()
        setParamOffset4(offset4)
        t1Length = self.form.doubleSpinBox_T1.value()
        setParamT1(t1Length)
        t2Length = self.form.doubleSpinBox_T2.value()
        setParamT2(t2Length)
        t3Length = self.form.doubleSpinBox_T3.value()
        setParamT3(t3Length)
        t4Length = self.form.doubleSpinBox_T4.value()
        setParamT4(t4Length)
        t5Length = self.form.doubleSpinBox_T5.value()
        setParamT5(t5Length)
        t6Length = self.form.doubleSpinBox_T6.value()
        setParamT6(t6Length)
        t7Length = self.form.doubleSpinBox_T7.value()
        setParamT7(t7Length)
        t8Length = self.form.doubleSpinBox_T8.value()
        setParamT8(t8Length)
        t9Length = self.form.doubleSpinBox_T9.value()
        setParamT9(t9Length)
        t10Length = self.form.doubleSpinBox_T10.value()
        setParamT10(t10Length)
        t11Length = self.form.doubleSpinBox_T11.value()
        setParamT11(t11Length)
        t12Length = self.form.doubleSpinBox_T12.value()
        setParamT12(t12Length)
        t13Length = self.form.doubleSpinBox_T13.value()
        setParamT13(t13Length)
        t14Length = self.form.doubleSpinBox_T14.value()
        setParamT14(t14Length)
        t15Length = self.form.doubleSpinBox_T15.value()
        setParamT15(t15Length)
        t16Length = self.form.doubleSpinBox_T16.value()
        setParamT16(t16Length)
        t17Length = self.form.doubleSpinBox_T17.value()
        setParamT17(t17Length)
        t18Length = self.form.doubleSpinBox_T18.value()
        setParamT18(t18Length)
        t19Length = self.form.doubleSpinBox_T19.value()
        setParamT19(t19Length)
        t20Length = self.form.doubleSpinBox_T20.value()
        setParamT20(t20Length)

    def show(self):
        """show the form"""
        # show the form using the builtin exec_() function
        self.form.exec_()

    def reject(self):
        """handle reject calls"""
        FreeCAD.Console.PrintMessage("Reject Signal")
        self.quit()

    def accept(self):
        """handle accept calls"""
        self.quit()

    def quit(self):
        """handle quit calls, close the form"""
        self.form.close()

    def reset(self):
        """handle reset calls"""
        pass


def Show():
    """ Exibe Janela Mach Door CAM Config """
    #if not FreeCAD.ActiveDocument:
    #    QtGui.QMessageBox.warning(FreeCADGui.getMainWindow(), "Warning", "Nenhum arquivo aberto")
    #    return

    #jobs = FreeCAD.ActiveDocument.findObjects("Path::FeaturePython", "Job.*")
    #if len(jobs) == 0:
    #    QtGui.QMessageBox.warning(FreeCADGui.getMainWindow(), "Warning", "Nenhum trabalho no documento ativo")
    #    return

    # create a MachDoorCAMConfigPanel form object
    panel = MachDoorCAMConfigPanel()
    # Show the form
    panel.show()
