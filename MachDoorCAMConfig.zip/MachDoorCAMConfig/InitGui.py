
"""FeedsAndSpeeds module for FreeCAD."""

import FreeCAD, FreeCADGui
import InitMachDoorCAMConfig