# -*- coding: utf-8 -*-

# ***************************************************************************
# *                                                                         *
# *   Copyright (c) 2020-2024 Daniel Wood <s.d.wood.82@googlemail.com>      *
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU Lesser General Public License (LGPL)    *
# *   as published by the Free Software Foundation; either version 2 of     *
# *   the License, or (at your option) any later version.                   *
# *   for detail see the LICENCE text file.                                 *
# *                                                                         *
# *   This program is distributed in the hope that it will be useful,       *
# *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
# *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
# *   GNU Library General Public License for more details.                  *
# *                                                                         *
# *   You should have received a copy of the GNU Library General Public     *
# *   License along with this program; if not, write to the Free Software   *
# *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  *
# *   USA                                                                   *
# *                                                                         *
# ***************************************************************************

import FreeCADGui
from PySide import QtGui
import CAMMachDoorCAMConfigGui
import os

__dir__ = os.path.dirname(__file__)
iconPath = os.path.join( __dir__, 'Icons' )

def getIcon(iconName):
     return os.path.join( iconPath , iconName)

def updateMenu(workbench):

    if workbench == 'CAMWorkbench':
    
        print('MachDoor CAM Config Addon carregado:', workbench)

        mw = FreeCADGui.getMainWindow()
        addonMenu = None

        # Find the main path menu
        pathMenu = mw.findChild(QtGui.QMenu, "&CAM")

        for menu in pathMenu.actions():
            if menu.text() == "CAM Addons":
                # create a new addon menu
                addonMenu = menu.menu()
                break

        if addonMenu is None:
            addonMenu = QtGui.QMenu("CAM Addons")
            addonMenu.setObjectName("CAM_Addons")

            # Find the dressup menu entry
            dressupMenu = mw.findChild(QtGui.QMenu, "Path Dressup")

            #addonMenu.setTitle("CAM Addons")
            pathMenu.insertMenu(dressupMenu.menuAction(), addonMenu)

        # create an action for this addon
        action = QtGui.QAction(addonMenu)
        action.setText("Mach Door CAM Config")
        action.setIcon(QtGui.QPixmap(getIcon('CAM_MachDoorCAMConfig.svg')))
        action.setStatusTip("Teste")
        action.triggered.connect(CAMMachDoorCAMConfigGui.Show)

        # append this addon to addon menu
        addonMenu.addAction(action)

FreeCADGui.getMainWindow().workbenchActivated.connect(updateMenu)
